// No longer needed, as logic is encapsulated in the web component
